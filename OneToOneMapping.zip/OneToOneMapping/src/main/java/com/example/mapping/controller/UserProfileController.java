/**
 * 
 */
package com.example.mapping.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.mapping.entity.UserProfile_parent;
import com.example.mapping.service.UserProfileServiceImple;

@RestController
@RequestMapping("userProfile")
public class UserProfileController {

	@Autowired
	private UserProfileServiceImple serviceImple;

	@PostMapping("/add")
	public ResponseEntity<String> saveUserProfile(@RequestBody UserProfile_parent userProfile) {
		serviceImple.saveUserProfile(userProfile);
		return new ResponseEntity<String>("Data added successfully", HttpStatus.OK);
	}
/*	
	// post-man
	// POST-http://localhost:9999/userProfile/add
	
	{
		"phoneNumber":"9876565443",
		"dateOfBirth":"23/09/1994",
		"address":"bhubaneshwar",
		"user":{
			"userId":2
		}
	}
*/
}
