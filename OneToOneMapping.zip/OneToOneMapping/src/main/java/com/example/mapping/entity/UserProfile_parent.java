/**
 * 
 */
package com.example.mapping.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * @author amod.kunwar
 *
 */
@Entity
@Table(name = "user_profiles_parent_table")
public class UserProfile_parent {

	@Id
	@GenericGenerator(name = "auto", strategy = "increment")
	@GeneratedValue(generator = "auto")
	@Column(name = "userprofile_id")
	private Integer userProfileId;

	@Column(name = "phone_number")
	public String phoneNumber;

	@Column(name = "dob")
	private String dateOfBirth;

	@Column(name = "address")
	private String address;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "u_id", nullable = false, referencedColumnName = "user_id")
	private User_child user;

	public UserProfile_parent() {
		System.out.println(this.getClass().getSimpleName() + " object created");
	}

	public UserProfile_parent(String phoneNumber, String dateOfBirth, String address) {
		super();
		this.phoneNumber = phoneNumber;
		this.dateOfBirth = dateOfBirth;
		this.address = address;
	}

	public Integer getUserProfileId() {
		return userProfileId;
	}

	public void setUserProfileId(Integer userProfileId) {
		this.userProfileId = userProfileId;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public User_child getUser() {
		return user;
	}

	public void setUser(User_child user) {
		this.user = user;
	}

}
