/**
 * 
 */
package com.example.mapping.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.mapping.entity.User_child;
import com.example.mapping.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.example.mapping.service.UserService#saveUserAndUserProfile(com.example.
	 * mapping.entity.User, com.example.mapping.entity.UserProfile)
	 */
	@Override
	public void saveUser(User_child user) {
		userRepository.save(user);

	}

}
