/**
 * 
 */
package com.example.mapping.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.mapping.entity.UserProfile_parent;
import com.example.mapping.repository.UserProfileRepository;

/**
 * @author amod.kunwar
 *
 */
@Service
public class UserProfileServiceImple implements UserProfileService {

	@Autowired
	private UserProfileRepository userProfileRepository;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.example.mapping.service.UserProfileService#saveUserProfile(com.example.
	 * mapping.entity.UserProfile)
	 */
	@Override
	public void saveUserProfile(UserProfile_parent userProfile) {
		userProfileRepository.save(userProfile);

	}

}
