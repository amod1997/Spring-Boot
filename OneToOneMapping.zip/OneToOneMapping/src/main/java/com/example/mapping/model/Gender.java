/**
 * 
 */
package com.example.mapping.model;

/**
 * @author amod.kunwar
 *
 */
public enum Gender {

	MALE,
	FEMALE
	
}
