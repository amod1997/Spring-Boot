/**
 * 
 */
package com.example.mapping.service;

import com.example.mapping.entity.User_child;

public interface UserService {

	public void saveUser(User_child user);

}
