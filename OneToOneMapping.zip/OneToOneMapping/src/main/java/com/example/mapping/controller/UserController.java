/**
 * 
 */
package com.example.mapping.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.mapping.entity.User_child;
import com.example.mapping.service.UserServiceImpl;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserServiceImpl userServiceImpl;

	@PostMapping("/add")
	public Integer saveDetailsOfUser(@RequestBody User_child user) {
		userServiceImpl.saveUser(user);
		return user.getUserId();
	}
/*	
	// post-man
	// POST-http://localhost:9999/user/add
	
	{	
		"userName":"Shanku",
		"email":"shanku@gmail.com",
		"userPassword":"12345"
	}
*/
}
