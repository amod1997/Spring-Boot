/**
 * 
 */
package com.example.mapping.service;

import com.example.mapping.entity.UserProfile_parent;

/**
 * @author amod.kunwar
 *
 */
public interface UserProfileService {

	public void saveUserProfile(UserProfile_parent userProfile);

}
