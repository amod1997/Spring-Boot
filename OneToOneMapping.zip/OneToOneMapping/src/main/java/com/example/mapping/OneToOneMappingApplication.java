package com.example.mapping;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.mapping.entity.User_child;
import com.example.mapping.entity.UserProfile_parent;
import com.example.mapping.repository.UserRepository;

@SpringBootApplication
public class OneToOneMappingApplication implements CommandLineRunner {

	@Autowired
	private UserRepository userRepository;

	public static void main(String[] args) {
		SpringApplication.run(OneToOneMappingApplication.class, args);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.boot.CommandLineRunner#run(java.lang.String[])
	 */
	@Override
	public void run(String... args) throws Exception {

		User_child user = new User_child("Amod", "amodkunwar@gmail.com", "123");

		UserProfile_parent userProfile = new UserProfile_parent("9937043734", "25/02/1995", "Bangalore");

		user.setUserProfile(userProfile);
		userProfile.setUser(user);

		userRepository.save(user);

	}

}
