/**
 * 
 */
package com.example.mapping.image;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

/**
 * @author amod.kunwar
 *
 */
@RestController
public class ImageFileController {

	private static final Logger logger = LoggerFactory.getLogger(ImageFileController.class);

	@Autowired
	private ImageFileServiceImpl fileServiceImpl;

	@PostMapping("/uploadFile")
	public UploadFileResponse uploadFile(@PathVariable("file") MultipartFile file) throws FileStorageException {

		logger.info("Trying to add file");

		ImageFile imageFile = fileServiceImpl.storeFile(file);

		String imageDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath().path("/downloadFile/")
				.path(imageFile.getImageId()).toUriString();

		return new UploadFileResponse(imageFile.getImageName(), imageDownloadUri, file.getContentType(),
				file.getSize());
	}

//	 @PostMapping("/uploadMultipleFiles")
//	 public List<UploadFileResponse> uploadMultipleFiles(@RequestParam("files") MultipartFile[] files) {
//		 return Arrays.asList(files)
//	                .stream()
//	                .map(file -> uploadFile(file))
//	                .collect(Collectors.toList());
//	 }

}
