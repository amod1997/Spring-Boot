/**
 * 
 */
package com.example.mapping.image;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.example.mapping.repository.ImageFileRepository;

/**
 * @author amod.kunwar
 *
 */
@Service
public class ImageFileServiceImpl implements ImageFileService {

	@Autowired
	private ImageFileRepository fileRepository;

	@Override
	public ImageFile storeFile(MultipartFile file) throws FileStorageException {

		String fileName = StringUtils.cleanPath(file.getOriginalFilename());

		try {
			if (fileName.contains("..")) {
				throw new FileStorageException("Sorry! Filename contains invalid path sequence " + fileName);
			}
			ImageFile imageFile = new ImageFile(fileName, file.getContentType(), file.getBytes());
			return fileRepository.save(imageFile);
		} catch (IOException e) {
			throw new FileStorageException("Could not store file " + fileName + ". Please try again!", e);
		}
	}

	@Override
	public ImageFile findImageById(String imageId) throws FileStorageException {
		return fileRepository.findById(imageId).orElseThrow(() -> new FileStorageException(imageId + " not found"));
	}

}
