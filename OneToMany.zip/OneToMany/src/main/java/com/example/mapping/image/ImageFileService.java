/**
 * 
 */
package com.example.mapping.image;

import org.springframework.web.multipart.MultipartFile;

/**
 * @author amod.kunwar
 *
 */
public interface ImageFileService {

	public ImageFile storeFile(MultipartFile file) throws FileStorageException;

	public ImageFile findImageById(String imageId) throws FileStorageException;

}
