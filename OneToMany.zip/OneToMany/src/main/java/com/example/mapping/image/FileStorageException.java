/**
 * 
 */
package com.example.mapping.image;

import java.io.IOException;

/**
 * @author amod.kunwar
 *
 */
public class FileStorageException extends Exception {

	private static final long serialVersionUID = 1L;

	/**
	 * @param string
	 */
	public FileStorageException(String message) {
		super(message);
	}

	/**
	 * @param string
	 * @param e
	 */
	public FileStorageException(String message, IOException e) {
		super(message, e);
	}

}
