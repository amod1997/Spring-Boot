/**
 * 
 */
package com.example.mapping.image;

/**
 * @author amod.kunwar
 *
 */
public class UploadFileResponse {

	private String imageName;
	private String imageDownloadUri;
	private String contentType;
	private long size;

	public UploadFileResponse(String imageName, String imageDownloadUri, String contentType, long size) {
		this.imageName = imageName;
		this.imageDownloadUri = imageDownloadUri;
		this.contentType = contentType;
		this.size = size;
	}

	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	public String getImageDownloadUri() {
		return imageDownloadUri;
	}

	public void setImageDownloadUri(String imageDownloadUri) {
		this.imageDownloadUri = imageDownloadUri;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public long getSize() {
		return size;
	}

	public void setSize(long size) {
		this.size = size;
	}

}
