/**
 * 
 */
package com.example.mapping.employee.service;

import com.example.mapping.dto.Employee;

public interface EmployeeService {

	public void saveEmployee(Employee employee);

}
