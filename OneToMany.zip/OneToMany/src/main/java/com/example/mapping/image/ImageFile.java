/**
 * 
 */
package com.example.mapping.image;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "Files")
public class ImageFile {

	@Id
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@GeneratedValue(generator = "uuid")
	@Column(name = "image_id")
	private String imageId;

	@Column(name = "image_name")
	private String imageName;

	@Column(name = "image_type")
	private String imageType;

	@Lob
	private byte[] data;

	public ImageFile() {
		System.out.println(this.getClass().getSimpleName() + " object created");
	}

	public ImageFile(String imageName, String imageType, byte[] data) {
		super();
		this.imageName = imageName;
		this.imageType = imageType;
		this.data = data;
	}

	public String getImageId() {
		return imageId;
	}

	public void setImageId(String imageId) {
		this.imageId = imageId;
	}

	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	public String getImageType() {
		return imageType;
	}

	public void setImageType(String imageType) {
		this.imageType = imageType;
	}

	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		this.data = data;
	}

}
