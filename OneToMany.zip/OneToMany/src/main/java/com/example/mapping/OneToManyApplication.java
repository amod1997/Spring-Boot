package com.example.mapping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OneToManyApplication {

	// To support WAR file deployment
//	@Override
//	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
//		return application.sources(OneToManyApplication.class);
//	}

	public static void main(String[] args) {
		SpringApplication.run(OneToManyApplication.class, args);
	}

}
