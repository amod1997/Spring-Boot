package com.example.mapping.utility;

public class OneToOneConstant {

	public OneToOneConstant() {
		throw new IllegalStateException("Utility class");
	}

	public static final String INCORRECT_REQUEST = "INCORRECT_REQUEST";

}
