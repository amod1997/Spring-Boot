/**
 * 
 */
package com.example.mapping.dto;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "CEO")
public class Ceo {

	@Id
	@GenericGenerator(name = "auto", strategy = "increment")
	@GeneratedValue(generator = "auto")
	@Column(name = "ceo_id")
	private Integer ceoId;

	@Column(name = "ceo_name")
	private String ceoName;

	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "comp_id", referencedColumnName = "company_id")
	private Company company;

	public Ceo() {
		System.out.println(this.getClass().getSimpleName() + " object created");
	}

	public Ceo(String ceoName) {
		this.ceoName = ceoName;
	}

	public Integer getCeoId() {
		return ceoId;
	}

	public void setCeoId(Integer ceoId) {
		this.ceoId = ceoId;
	}

	public String getCeoName() {
		return ceoName;
	}

	public void setCeoName(String ceoName) {
		this.ceoName = ceoName;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

}
