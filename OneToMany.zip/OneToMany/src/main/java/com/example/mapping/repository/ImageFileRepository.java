/**
 * 
 */
package com.example.mapping.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.mapping.image.ImageFile;

/**
 * @author amod.kunwar
 *
 */
public interface ImageFileRepository extends JpaRepository<ImageFile, String> {

}
