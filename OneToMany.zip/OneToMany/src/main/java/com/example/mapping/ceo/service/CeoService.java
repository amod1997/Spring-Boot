/**
 * 
 */
package com.example.mapping.ceo.service;

import com.example.mapping.dto.Ceo;

public interface CeoService {

	public void saveCeo(Ceo ceo);

	public Ceo findCeoById(Integer ceoId);

}
