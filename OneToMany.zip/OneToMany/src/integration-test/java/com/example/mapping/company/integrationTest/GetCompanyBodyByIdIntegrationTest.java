/**
 * 
 */
package com.example.mapping.company.integrationTest;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.mapping.OneToManyApplication;
import com.example.mapping.dto.Company;
import com.example.mapping.dto.Employee;

/**
 * @author amod.kunwar
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = OneToManyApplication.class, webEnvironment = SpringBootTest.WebEnvironment.NONE)
public class GetCompanyBodyByIdIntegrationTest {

	private static Logger logger = LoggerFactory.getLogger(GetAllCompanyIntegrationTest.class);

	String url = "http://localhost:9990/company/2";

	TestRestTemplate testRestTemplate = new TestRestTemplate();
	HttpHeaders httpHeaders = new HttpHeaders();

	List<Employee> employeeList = new ArrayList<>();

	@Test
	public void test() {
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);

		Company company = new Company();

		company.setCompanyName("HP");

		HttpEntity<Company> httpRequest = new HttpEntity<Company>(company);

		logger.info("Getting the response with the help of Id. In object format.");

		ResponseEntity<Company> response = testRestTemplate.exchange(url, HttpMethod.GET, httpRequest, Company.class);

		System.out.println(response.getStatusCodeValue());
		System.out.println(response.getBody().toString());

	}

}
