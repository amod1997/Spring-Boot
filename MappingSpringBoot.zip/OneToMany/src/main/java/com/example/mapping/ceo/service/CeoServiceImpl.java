/**
 * 
 */
package com.example.mapping.ceo.service;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.mapping.ceo.controller.CeoController;
import com.example.mapping.dto.Ceo;
import com.example.mapping.repository.CeoRepository;

@Service
public class CeoServiceImpl implements CeoService {
	
	private static final Logger logger = LoggerFactory.getLogger(CeoController.class);

	@Autowired
	private CeoRepository ceoRepository;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.example.mapping.ceo.service.CeoService#saveCeo(com.example.mapping.dto.
	 * Ceo)
	 */
	@Override
	public void saveCeo(Ceo ceo) {
		if (ceo != null)
			logger.info("Adding the ceo data into the database.");
			ceoRepository.save(ceo);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.example.mapping.ceo.service.CeoService#findCeoById(java.lang.Integer)
	 */
	@Override
	public Ceo findCeoById(Integer ceoId) {
		Optional<Ceo> findById = null;
		if (ceoId != null && ceoId != 0) {
			logger.info("Fetching the ceo data with the help of Id");
			findById = ceoRepository.findById(ceoId);
		}
		return findById.get();
	}

}
