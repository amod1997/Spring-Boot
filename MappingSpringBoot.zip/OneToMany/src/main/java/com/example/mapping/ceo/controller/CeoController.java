/**
 * 
 */
package com.example.mapping.ceo.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.mapping.ceo.service.CeoServiceImpl;
import com.example.mapping.dto.Ceo;

/**
 * @author amod.kunwar
 *
 */
@RestController
@RequestMapping("/ceo")
public class CeoController {

	private static final Logger logger = LoggerFactory.getLogger(CeoController.class);

	@Autowired
	private CeoServiceImpl ceoService;

	@PostMapping("/add")
	public ResponseEntity<String> addCeo(@RequestBody Ceo ceo) {
		logger.info("Ceo data getting add into the database");
		ceoService.saveCeo(ceo);
		return new ResponseEntity<>("Ceo data addedd successfully.", HttpStatus.OK);
	}

	@GetMapping("/{ceoId}")
	public Ceo getDetialsById(@PathVariable("ceoId") Integer ceoId) {
		logger.info("Fetching the ceo data with the help of Id.");
		return ceoService.findCeoById(ceoId);
	}

}
