package com.example.mapping.company.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.mapping.ceo.controller.CeoController;
import com.example.mapping.company.service.CompanyServiceImpl;
import com.example.mapping.dto.Company;

@RestController
@RequestMapping("/company")
public class CompanyController {

	private static final Logger logger = LoggerFactory.getLogger(CeoController.class);

	@Autowired
	private CompanyServiceImpl companyService;

	@PostMapping("/add")
	public ResponseEntity<String> addCompany(@RequestBody Company company) {
		logger.info("Adding the company data into the database");
		companyService.saveCompany(company);
		return new ResponseEntity<String>("Company data added.", HttpStatus.OK);
	}

	@GetMapping("/{companyId}")
	public Optional<Company> findCompanyById(@PathVariable("companyId") Integer companyId) throws Exception {
		logger.info("Fetching the company data with the help of Id");
		return companyService.findById(companyId);
	}

	@GetMapping("/all")
	public List<Company> getAllCompany() {
		logger.info("Fetching All data of Company");
		return companyService.getAllCompany();
	}

	@DeleteMapping("/deleteAll")
	public ResponseEntity<String> deleteAllCompany() {
		logger.info("deleting All data of Company");
		companyService.deleteAllCompany();
		return new ResponseEntity<String>("All Company data deleted.", HttpStatus.OK);
	}

	@PutMapping("/updateCompany/{companyId}")
	public ResponseEntity<String> updateCompany(@RequestBody Company company,
			@PathVariable("companyId") Integer companyId) throws Exception {
		companyService.updateCompany(company, companyId);
		return new ResponseEntity<String>("Company Data Updated successfully.", HttpStatus.OK);
	}

}
