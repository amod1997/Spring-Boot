/**
 * 
 */
package com.example.mapping.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * @author amod.kunwar
 *
 */
@Entity
@Table(name = "Employee")
public class Employee {

	@Id
	@GenericGenerator(name = "auto", strategy = "increment")
	@GeneratedValue(generator = "auto")
	@Column(name = "emp_id")
	private Integer empId;

	@Column(name = "emp_name")
	private String empName;

	@ManyToOne // (fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "comp_id", referencedColumnName = "company_id")
	private Company company;

	@ManyToOne
	@JoinColumn(name = "ceo_id", referencedColumnName = "ceo_id")
	private Ceo ceo;

	public Employee() {
		System.out.println(this.getClass().getSimpleName() + " object created");
	}

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	public Ceo getCeo() {
		return ceo;
	}

	public void setCeo(Ceo ceo) {
		this.ceo = ceo;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", company=" + company + ", ceo=" + ceo + "]";
	}

}
