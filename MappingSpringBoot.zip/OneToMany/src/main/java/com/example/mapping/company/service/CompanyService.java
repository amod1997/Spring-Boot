/**
 * 
 */
package com.example.mapping.company.service;

import java.util.List;
import java.util.Optional;

import com.example.mapping.dto.Company;

/**
 * @author amod.kunwar
 *
 */
public interface CompanyService {

	public void saveCompany(Company company);

	public void updateCompany(Company company, Integer companyId) throws Exception;

	public Optional<Company> findById(Integer companyId) throws Exception;

	public List<Company> getAllCompany();

	public void deleteAllCompany();

}
