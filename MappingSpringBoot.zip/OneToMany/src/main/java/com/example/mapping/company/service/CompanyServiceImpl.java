/**
 * 
 */
package com.example.mapping.company.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.mapping.ceo.controller.CeoController;
import com.example.mapping.dto.Company;
import com.example.mapping.exception.RecordNotFoundException;
import com.example.mapping.repository.CompanyRepository;

@Service
public class CompanyServiceImpl implements CompanyService {

	private static final Logger logger = LoggerFactory.getLogger(CeoController.class);

	@Autowired
	private CompanyRepository companyRepository;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.example.mapping.service.CompanyService#saveCompany(com.example.mapping.
	 * dto.Company)
	 */
	@Override
	public void saveCompany(Company company) {
		if (company != null)
			logger.info("Adding the company data into the database.");
		companyRepository.save(company);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.example.mapping.service.CompanyService#findById(java.lang.Integer)
	 */
	@Override
	public Optional<Company> findById(Integer companyId) throws Exception {
		Optional<Company> findById = companyRepository.findById(companyId);
		if (!findById.isPresent()) {
			logger.error(companyId + " id not found");
			throw new RecordNotFoundException(companyId + " not found");
		}
		return findById;
		// return companyRepository.findById(companyId).orElseThrow(() -> new
		// RecordNotFoundException("Id is not valid"));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.example.mapping.company.service.CompanyService#getAllCompany()
	 */
	@Override
	public List<Company> getAllCompany() {
		List<Company> companyList = new ArrayList<>();
		logger.info("Getting all value of Company.");
		companyRepository.findAll().forEach(companys -> companyList.add(companys));
		return companyList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.example.mapping.company.service.CompanyService#deleteAllCompany()
	 */
	@Override
	public void deleteAllCompany() {
		logger.info("Deleting all value of Company.");
		companyRepository.deleteAll();

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.example.mapping.company.service.CompanyService#updateCompany(com.example.
	 * mapping.dto.Company)
	 */
	@Override
	public void updateCompany(Company company, Integer companyId) throws Exception {
		Optional<Company> findById = findById(companyId);
		if (company != null && companyId != null) {
			if (!findById.isPresent()) {
				throw new RecordNotFoundException(companyId + " not found");
			}
			if (company.getCompanyName().isEmpty() || company.getCeo() == null) {
				company.setCeo(findById.get().getCeo());
			}
			if (company.getCompanyName() == null || company.getCompanyName().isEmpty()) {
				company.setCompanyName(findById.get().getCompanyName());
			}
//			if (company.getEmployeeList().isEmpty() || company.getEmployeeList() == null) {
//				company.setEmployeeList(findById.get().getEmployeeList());
//			}
			company.setCompanyId(companyId);
			companyRepository.save(company);
		}

	}

}
