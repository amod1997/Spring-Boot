/**
 * 
 */
package com.example.mapping.employee.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.mapping.ceo.controller.CeoController;
import com.example.mapping.dto.Employee;
import com.example.mapping.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	private static final Logger logger = LoggerFactory.getLogger(CeoController.class);

	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public void saveEmployee(Employee employee) {
		if (employee != null)
			logger.info("Adding employee data into the databse.");
		employeeRepository.save(employee);
	}
}
