/*

package com.example.mapping.postman;

public class InsertDataThroughPostMan {

	// for Ceo
	http:// localhost:9990/ceo/add
	{
		"ceoName":"Nitin Rakesh"
	}

	// for company
	http:// localhost:9990/company/add
	{
		"companyName":"mphasis",
		"ceo":{
				"ceoId":"1"
			},
		"employeeList":[{
			"empName":"Amod",
			"ceo":{
					"ceoId":1
			},
			"company":{
				"companyId":"1"
			}
		}]
	}

	// for Employee
	http:// localhost:9990/employee/add

	{
		"empName":"Amod",
		"company":{
			"companyId":"1"
		},
			"ceo":{
				"ceoId":"1"
			}
	}

}

*/
