/**
 * 
 */
package com.example.mapping.controller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.mapping.company.controller.CompanyController;
import com.example.mapping.company.service.CompanyServiceImpl;
import com.example.mapping.dto.Company;
import com.example.mapping.repository.CompanyRepository;

@RunWith(SpringRunner.class)

public class CompanyControllerTest {

	@InjectMocks
	private CompanyController companyController;

	@Mock
	private CompanyServiceImpl companyService;

	@Mock
	private CompanyRepository companyRepository;

	@Test
	public void testfindCompanyById() throws Exception {
		Company company = new Company("Mphasis");
		Mockito.doReturn(company).when(companyService).findById(1);
		companyController.findCompanyById(1);
	}

	@Test
	public void testSaceCompany() {
		Company company = new Company("Mphasis");
		Mockito.doReturn(company).when(companyRepository).save(company);
		companyController.addCompany(company);
	}

}
