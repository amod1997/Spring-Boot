package com.example.demo.entity;

import java.util.UUID;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Person_demo")
public class Person {

	@Id
	// @GeneratedValue
	private UUID id = UUID.randomUUID();
	private String name;
	private Integer age;
	private String emailId;

	public Person() {
		System.out.println(this.getClass().getSimpleName() + " class object created");
	}

	public Person(UUID id, String name, Integer age, String emailId) {
		this.id = id;
		this.name = name;
		this.age = age;
		this.emailId = emailId;
	}

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	@Override
	public String toString() {
		return "Person [id=" + id + ", name=" + name + ", age=" + age + ", emailId=" + emailId + "]";
	}

}
