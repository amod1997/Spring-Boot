package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Person;
import com.example.demo.repository.PersonRepository;

@Service
public class PersonService {

	@Autowired
	private PersonRepository personRepository;

	public List<Person> getAllPerson() {
		List<Person> persons = new ArrayList<Person>();
		personRepository.findAll().forEach(person -> persons.add(person));
		return persons;
	}

	public Person getPersonById(UUID id) {
		return personRepository.findById(id).get();
	}

	public Person saveOrUpdate(Person person) {
		return personRepository.save(person);
	}

	public void delete(UUID id) {
		personRepository.deleteById(id);
	}

}
