package com.example.mapping.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.mapping.dto.BycUser;
import com.example.mapping.repository.RegistrationRepository;

@Service
public class LoginServiceImpl implements LoginService {

	@Autowired
	private RegistrationRepository registrationRepository;

	@Override
	public boolean isValidUser(String email, String password) {
		if (email != null && password != null) {
			BycUser findByEmailAndPassword = registrationRepository.findByUserEmailAndUserPassword(email);
			if (email.equals(findByEmailAndPassword.getUserEmail())
					&& password.equals(findByEmailAndPassword.getUserPassword())) {
				return true;
			}
		}
		return false;
	}

}
