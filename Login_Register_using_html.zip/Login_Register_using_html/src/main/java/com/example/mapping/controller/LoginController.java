package com.example.mapping.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.example.mapping.service.LoginService;

@RestController
public class LoginController {

	@Autowired
	private LoginService loginService;

	@PostMapping("/loginControl")
	public ModelAndView loginPage(@RequestParam String email, @RequestParam String password) {
		boolean validUser = loginService.isValidUser(email, password);
		if (validUser) {
			return new ModelAndView("home.html");
		} else {
			return new ModelAndView("failed.html");
		}
	}
}
