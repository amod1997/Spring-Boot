package com.example.mapping.service;

public interface LoginService {

	public boolean isValidUser(String email, String password);
	
}
