package com.example.mapping.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.example.mapping.dto.BycUser;
import com.example.mapping.service.RegistrationService;

@RestController
@Scope("session")
public class RegistrationController {

	@Autowired
	private RegistrationService registrationService;

//	@PostMapping("/add")
//	public ResponseEntity<String> addBycUser(@Valid @RequestBody BycUser bycUser) {
//		registrationService.saveBycUser(bycUser);
//		return new ResponseEntity<String>("Byc user added successfully.", HttpStatus.OK);
//	}

	@PostMapping("/form")
	public @ResponseBody ModelAndView addBycUser(@RequestParam(name = "name") String name,
			@RequestParam(name = "email") String email, @RequestParam(name = "number") Long number,
			@RequestParam(name = "password") String password, @RequestParam(name = "dl") String dl,
			@RequestParam(name = "secquestion") String secquestion,
			@RequestParam(name = "secanswer") String secanswer) {
		BycUser bycUser = new BycUser();

		bycUser.setUserName(name);
		bycUser.setDrivingLicense(dl);
		bycUser.setUserEmail(email);
		bycUser.setUserMobile(number);
		bycUser.setUserPassword(password);
		bycUser.setSecurityQuestion(secquestion);
		bycUser.setSecurityAnswer(secanswer);

		registrationService.saveBycUser(bycUser);
		return new ModelAndView("registerSuccess.html");
	}
}
