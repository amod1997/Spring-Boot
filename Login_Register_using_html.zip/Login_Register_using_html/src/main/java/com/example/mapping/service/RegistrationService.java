package com.example.mapping.service;

import com.example.mapping.dto.BycUser;

public interface RegistrationService {

	public void saveBycUser(BycUser bycUser);

}
