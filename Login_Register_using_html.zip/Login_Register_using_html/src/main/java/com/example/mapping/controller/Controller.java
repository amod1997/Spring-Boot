package com.example.mapping.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class Controller {

//	@Autowired
//	private RegistrationRepository registrationRepository;

	@GetMapping("/home")
	public ModelAndView index() {
		return new ModelAndView("index.html");
	}

	@GetMapping("/signup.html")
	public ModelAndView signup() {
		return new ModelAndView("signup.html");
	}

	@GetMapping("/login.html")
	public ModelAndView login() {
		return new ModelAndView("login.html");
	}

//	  @Autowired
//	  UserRepository userR;
//	  @GetMapping
//	  public String currentUser(@ModelAttribute("user") @Valid UserRegistrationDto userDto, BindingResult result, Model model) {
//
//	      Authentication loggedInUser = SecurityContextHolder.getContext().getAuthentication();
//	      String email = loggedInUser.getName(); 
//
//	       User user = userR.findByEmailAddress(email);
//	      String firstname = user.getFirstName();
//	       model.addAttribute("firstName", firstname);
//	      model.addAttribute("emailAddress", email);
//
//	      return "userProfile1"; //this is the name of my template
//	  }
//
//	@GetMapping
//	public String currentUser(@ModelAttribute("bycUser") @Valid BycUser bycUser, BindingResult result, Model model) {
//		Authentication loggedinUser = SecurityContextHolder.getContext().getAuthentication();
//		return null;
//	}

}
