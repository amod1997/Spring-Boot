package com.example.mapping.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.mapping.dto.BycUser;
import com.example.mapping.repository.RegistrationRepository;

@Service
public class RegistrationServiceImpl implements RegistrationService {

	@Autowired
	private RegistrationRepository registrationRepository;

	@Override
	public void saveBycUser(BycUser bycUser) {
		if (bycUser != null) {
			registrationRepository.save(bycUser);
		}

	}

}
