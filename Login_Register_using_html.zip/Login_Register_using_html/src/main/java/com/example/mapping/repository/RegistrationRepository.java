package com.example.mapping.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.mapping.dto.BycUser;

@Repository
public interface RegistrationRepository extends JpaRepository<BycUser, String> {

	@Query("select byc from BycUser as byc where byc.userEmail=:userEmail")
	public BycUser findByUserEmailAndUserPassword(String userEmail);

}
