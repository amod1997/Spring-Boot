package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Employee;
import com.example.demo.service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	@GetMapping("/employee")
	public List<Employee> getAllEmployee() {
		return employeeService.getAllEmployee();
	}

	@GetMapping("/employee/{id}")
	public Employee getDetailsById(@PathVariable("id") Integer id) throws Exception {
		Optional<Employee> detailsById = employeeService.getDetailsById(id);
		if (!detailsById.isPresent()) {
			throw new Exception("Cannot find the employee with Id " + id);
		}
		return detailsById.get();
	}

	@PostMapping("/employee/add")
	public Employee createNewEmployee(Employee employee) {
		return employeeService.addNewEmployee(employee);
	}

	@PutMapping("/employee/add")
	public Employee updateEmployee(Employee employee, @PathVariable("id") Integer id) throws Exception {
		Optional<Employee> updateEmployee = employeeService.getDetailsById(id);
		if (!updateEmployee.isPresent()) {
			throw new Exception("Cannot find the employee with Id " + id);
		}
		if (employee.getEmpName() == null || employee.getEmpName().isEmpty()) {
			employee.setEmpName(updateEmployee.get().getEmpName());
		}
		if (employee.getEmpAge() == 0) {
			employee.setEmpAge(updateEmployee.get().getEmpAge());
		}

		if (employee.getEmpEmailId() == null || employee.getEmpEmailId().isEmpty()) {
			employee.setEmpEmailId(updateEmployee.get().getEmpEmailId());
		}

		if (employee.getEmpSalary() == 0.0) {
			employee.setEmpSalary(updateEmployee.get().getEmpSalary());
		}

		employee.setEmpId(id);

		return employeeService.updateEmployee(employee);

	}

	@DeleteMapping("/employee/delete/{id}")
	public void deleteEmployeeById(Integer id) throws Exception {
		Optional<Employee> detailsById = employeeService.getDetailsById(id);

		if (!detailsById.isPresent()) {
			throw new Exception("Cannot find the employee with Id " + id);
		}

		employeeService.deleteEmployeeById(id);
	}

	@DeleteMapping("/delete/all")
	public void deleteAllEmployee() {
		employeeService.deleteAllEmployee();
	}

}
