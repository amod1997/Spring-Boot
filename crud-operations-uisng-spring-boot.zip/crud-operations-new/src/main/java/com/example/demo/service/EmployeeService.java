package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Employee;

@Service
public interface EmployeeService {

	public List<Employee> getAllEmployee();

	public Optional<Employee> getDetailsById(Integer id);

	public Employee addNewEmployee(Employee employee);

	public Employee updateEmployee(Employee employee);

	public void deleteEmployeeById(Integer id);

	public void deleteAllEmployee();

}
