package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Employee_Demo")
public class Employee {

	@Id
	@GeneratedValue
	private Integer id;

	private String empName;

	private String empEmailId;

	private Double empSalary;

	private Integer empAge;

	public Employee() {
		System.out.println(this.getClass().getSimpleName() + " object created");
	}

	public Employee(Integer id, String empName, String empEmailId, Double empSalary, Integer empAge) {
		this.id = id;
		this.empName = empName;
		this.empEmailId = empEmailId;
		this.empSalary = empSalary;
		this.empAge = empAge;
	}

	public Integer getEmpAge() {
		return empAge;
	}

	public void setEmpAge(Integer empAge) {
		this.empAge = empAge;
	}

	public Integer getEmpId() {
		return id;
	}

	public void setEmpId(Integer empId) {
		this.id = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpEmailId() {
		return empEmailId;
	}

	public void setEmpEmailId(String empEmailId) {
		this.empEmailId = empEmailId;
	}

	public Double getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(Double empSalary) {
		this.empSalary = empSalary;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + id + ", empName=" + empName + ", empEmailId=" + empEmailId + ", empSalary="
				+ empSalary + ", empAge=" + empAge + "]";
	}

}
