package com.example.mapping.controller;

import java.net.URISyntaxException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.mapping.service.StudentService;

@RestController
@RequestMapping("/location")
public class StudentController {

	@Autowired
	private StudentService studentService;

	@GetMapping("/all")
	public List<Integer> getAllLocationOfParent() throws URISyntaxException {
		return studentService.getAllLocationFromParent();
	}

}
