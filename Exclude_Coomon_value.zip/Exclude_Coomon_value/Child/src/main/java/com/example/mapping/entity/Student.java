package com.example.mapping.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "Student")
public class Student {

	@Id
	@GenericGenerator(name = "auto", strategy = "increment")
	@GeneratedValue(generator = "auto")
	@Column(name = "student_id")
	private Integer studentId;

	@Column(name = "student_name")
	private String studentName;

	@Column(name = "loc_num")
	private Integer locNum;

	public Student() {
		System.out.println(this.getClass().getSimpleName() + " object created");
	}

	public Student(String studentName, Integer locNum) {
		super();
		this.studentName = studentName;
		this.locNum = locNum;
	}

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public Integer getLocNum() {
		return locNum;
	}

	public void setLocNum(Integer locNum) {
		this.locNum = locNum;
	}

}
