package com.example.mapping.service;

import java.net.URISyntaxException;
import java.util.List;

public interface StudentService {

	public List<Integer> getAllLocationFromParent() throws URISyntaxException;
	
}
