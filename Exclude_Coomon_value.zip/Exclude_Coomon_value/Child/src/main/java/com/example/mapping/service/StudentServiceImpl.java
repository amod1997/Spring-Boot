package com.example.mapping.service;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.mapping.entity.Student;
import com.example.mapping.repository.StudentRepository;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentRepository studentRepository;

	@Override
	public List<Integer> getAllLocationFromParent() throws URISyntaxException {

		List<Integer> allLocationNumber = studentRepository.getAllLocationNumber();

		List<Integer> body = null;
		RestTemplate restTemplate = new RestTemplate();
		URI uri = getUri("http://localhost:8080/address/locNum");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		Student student = new Student();
		HttpEntity<Student> request = new HttpEntity<Student>(student);
		ResponseEntity<List<Integer>> exchange = restTemplate.exchange(uri, HttpMethod.GET, request,
				new ParameterizedTypeReference<List<Integer>>() {
				});
		if (exchange != null && exchange.hasBody()) {
			body = exchange.getBody();
		}

		// body.stream().filter(allLocationNumbers ->
		// body.contains(allLocationNumbers)).collect(Collectors.toList());

		body.removeIf(x -> allLocationNumber.contains(x));

		return body;
	}

	private URI getUri(String url) throws URISyntaxException {
		return new URI(url);
	}

}
