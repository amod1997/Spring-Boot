package com.example.mapping;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.mapping.entity.Student;
import com.example.mapping.repository.StudentRepository;

@SpringBootApplication
public class ChildApplication implements ApplicationRunner {

	@Autowired
	private StudentRepository studentRepository;

	public static void main(String[] args) {
		SpringApplication.run(ChildApplication.class, args);
	}

	@Override
	public void run(ApplicationArguments args) throws Exception {
		studentRepository.save(new Student("Amod", 10));
		studentRepository.save(new Student("Kunwar", 20));

	}

}
