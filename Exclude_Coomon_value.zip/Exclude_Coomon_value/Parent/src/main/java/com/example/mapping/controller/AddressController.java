package com.example.mapping.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.mapping.entity.Address;
import com.example.mapping.service.AddressService;

@RestController
@RequestMapping("/address")
public class AddressController {

	@Autowired
	private AddressService addressService;

	@GetMapping("/all")
	public List<Address> getAllAddress() {
		return addressService.getAllAddress();
	}

	@GetMapping("/locNum")
	public List<Integer> getAllLocNum() {
		return addressService.getAllLocNum();
	}

}
