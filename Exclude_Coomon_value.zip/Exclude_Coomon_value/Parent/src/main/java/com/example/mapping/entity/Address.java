package com.example.mapping.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "Address")
public class Address {

	@Id
	@GenericGenerator(name = "auto", strategy = "increment")
	@GeneratedValue(generator = "auto")
	@Column(name = "add_id")
	private Integer addId;

	@Column(name = "loc_num")
	private Integer locNum;

	public Address() {
		System.out.println(this.getClass().getSimpleName() + " object created");
	}

	public Address(Integer locNum) {
		super();
		this.locNum = locNum;
	}

	public Integer getLocNum() {
		return locNum;
	}

	public void setLocNum(Integer locNum) {
		this.locNum = locNum;
	}

}
