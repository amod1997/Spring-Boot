package com.example.mapping.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.mapping.entity.Address;
import com.example.mapping.repository.AddressRepositoy;

@Service
public class AddressServiceImpl implements AddressService {

	@Autowired
	private AddressRepositoy addressRepositoy;

	@Override
	public List<Address> getAllAddress() {
		List<Address> addressList = new ArrayList<Address>();
		addressRepositoy.findAll().forEach(address -> addressList.add(address));
		return addressList;
	}

	@Override
	public List<Integer> getAllLocNum() {
		return addressRepositoy.getAllLocNum();
	}

}
