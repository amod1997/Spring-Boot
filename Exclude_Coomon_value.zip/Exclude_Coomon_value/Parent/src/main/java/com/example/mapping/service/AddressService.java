package com.example.mapping.service;

import java.util.List;

import com.example.mapping.entity.Address;

public interface AddressService {

	public List<Address> getAllAddress();
	
	public List<Integer> getAllLocNum();

}
