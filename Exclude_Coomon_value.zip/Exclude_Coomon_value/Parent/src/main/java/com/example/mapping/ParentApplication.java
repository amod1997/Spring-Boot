package com.example.mapping;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.mapping.entity.Address;
import com.example.mapping.repository.AddressRepositoy;

@SpringBootApplication
public class ParentApplication implements ApplicationRunner {

	@Autowired
	private AddressRepositoy addressRepositoy;

	public static void main(String[] args) {
		SpringApplication.run(ParentApplication.class, args);
	}

	@Override
	public void run(ApplicationArguments args) throws Exception {
		addressRepositoy.save(new Address(10));
		addressRepositoy.save(new Address(20));
		addressRepositoy.save(new Address(30));
		addressRepositoy.save(new Address(40));
		addressRepositoy.save(new Address(50));

	}

}
