package com.example.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Employee;
import com.example.repo.EmployeeRepo;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepo employeeRepo;

	@Override
	public void saveEmployee(Employee employee) {
		if (employee != null) {
			employeeRepo.save(employee);
		}

	}

	@Override
	public List<Employee> getAllEmployee() {
		List<Employee> listEmployee = new ArrayList<Employee>();
		employeeRepo.findAll().forEach(employees -> listEmployee.add(employees));
		return listEmployee;
	}

	public void givenData_convertIntoCSV() throws FileNotFoundException {

		List<Employee> dataLines = getAllEmployee();

		File csvOutputFile = new File("E:\\GitHub\\amod.csv");

		try (PrintWriter pw = new PrintWriter(csvOutputFile)) {

			// dataLines.stream().map(i->i.toString()).forEach(pw::println);

			dataLines.stream().map(Employee::toString).forEach(pw::println);

		}

		System.out.println("It's working");

	}

}
