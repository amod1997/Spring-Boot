package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.Employee;
import com.example.repo.EmployeeRepo;
import com.example.service.EmployeeServiceImpl;

@SpringBootApplication
public class CsvApplication implements ApplicationRunner {

	@Autowired
	private EmployeeRepo employeeRepo;

	@Autowired
	private EmployeeServiceImpl employeeServiceImpl;

	public static void main(String[] args) {
		SpringApplication.run(CsvApplication.class, args);
	}

	@Override
	public void run(ApplicationArguments args) throws Exception {
		employeeRepo.save(new Employee("Amod"));
		employeeRepo.save(new Employee("Kunwar"));
		employeeServiceImpl.givenData_convertIntoCSV();
	}

}
