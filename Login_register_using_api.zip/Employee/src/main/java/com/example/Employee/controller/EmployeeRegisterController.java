package com.example.Employee.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Employee.entity.Employee;
import com.example.Employee.service.EmployeeRegisterService;

/**
 * @author amod.kunwar
 *
 */
@RestController
@RequestMapping(value = "/employee")
public class EmployeeRegisterController {

	@Autowired
	private EmployeeRegisterService employeeRegisterService;

	@PostMapping(value = "/register")
	public Employee addNewEmployee(@RequestBody Employee employee) {
		return employeeRegisterService.addNewEmployee(employee);
	}

}
