/**
 * 
 */
package com.example.Employee.controller;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Employee.service.EmployeeLoginService;

/**
 * @author amod.kunwar
 *
 */
@RestController
@RequestMapping(value = "/employee")
public class EmployeeLoginController {
	@Autowired
	private EmployeeLoginService employeeLoginService;

	@GetMapping(value = "/login/{id}/{password}")
	public ResponseEntity<String> loginEmployee(@PathVariable("id") UUID id, @PathVariable("password") String password)
			throws Exception {
		boolean b =  employeeLoginService.loginEmployee(id, password);
		if(b)
			return new ResponseEntity<String>("Login Successfully", HttpStatus.OK);
		else
			return new ResponseEntity<String>("Invalid Credentials", HttpStatus.UNAUTHORIZED);
	}
}
