/**
 * 
 */
package com.example.Employee.service;

import org.springframework.stereotype.Service;

import com.example.Employee.entity.Employee;

/**
 * @author amod.kunwar
 *
 */
@Service
public interface EmployeeRegisterService {
	
	public Employee addNewEmployee(Employee employee);
	
}
