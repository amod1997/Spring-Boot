/**
 * 
 */
package com.example.Employee.implementations;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Employee.entity.Employee;
import com.example.Employee.repository.EmployeeRepository;
import com.example.Employee.service.EmployeeRegisterService;

/**
 * @author amod.kunwar
 *
 */
@Service
public class EmployeeRegisterServiceImpl implements EmployeeRegisterService {

	@Autowired
	private EmployeeRepository employeeRepository;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.example.Employee.service.EmployeeRegisterService#addNewEmployee(com.
	 * example.Employee.entity.Employee)
	 */
	@Override
	public Employee addNewEmployee(Employee employee) {
		return employeeRepository.save(employee);
	}

}
