/**
 * 
 */
package com.example.Employee.implementations;

import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Employee.entity.Employee;
import com.example.Employee.repository.EmployeeRepository;
import com.example.Employee.service.EmployeeLoginService;

/**
 * @author amod.kunwar
 *
 */
@Service
public class EmployeeLoginServiceImpl implements EmployeeLoginService {

	@Autowired
	private EmployeeRepository employeeRepository;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.example.Employee.service.EmployeeLoginService#loginEmployee(java.util.
	 * UUID, java.lang.String)
	 */
	@Override
	public Boolean loginEmployee(UUID id, String password) throws Exception {

		if (id != null && password != null) {
			Optional<Employee> o = employeeRepository.findById(id);
			if (id.equals(o.get().getId())
					&& password.equals(o.get().getPassword())) {
				return true;
			}
		}
		return false;
	}

}
