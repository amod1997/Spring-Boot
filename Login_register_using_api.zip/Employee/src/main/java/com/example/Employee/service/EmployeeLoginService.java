/**
 * 
 */
package com.example.Employee.service;

import java.util.UUID;

import org.springframework.stereotype.Service;

/**
 * @author amod.kunwar
 *
 */
@Service
public interface EmployeeLoginService {

	public Boolean loginEmployee(UUID id, String password) throws Exception;

}
