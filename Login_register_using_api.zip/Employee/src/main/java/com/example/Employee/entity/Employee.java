/**
 * 
 */
package com.example.Employee.entity;

import java.util.UUID;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author amod.kunwar
 *
 */
@Entity
@Table(name = "Employee")
public class Employee {

	@Id
	private UUID id = UUID.randomUUID();

	private String empName;

	private String empEmailId;

	private Double empSalary;

	private Integer empAge;

	private String password;

	public Employee() {
		System.out.println(this.getClass().getSimpleName() + " object created");
	}

	public Employee(UUID id, String empName, String empEmailId, Double empSalary, Integer empAge, String password) {
		this.id = id;
		this.empName = empName;
		this.empEmailId = empEmailId;
		this.empSalary = empSalary;
		this.empAge = empAge;
		this.password = password;
	}

	public Employee(String empName, String empEmailId, Double empSalary, Integer empAge, String password) {
		this.empName = empName;
		this.empEmailId = empEmailId;
		this.empSalary = empSalary;
		this.empAge = empAge;
		this.password = password;
	}

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpEmailId() {
		return empEmailId;
	}

	public void setEmpEmailId(String empEmailId) {
		this.empEmailId = empEmailId;
	}

	public Double getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(Double empSalary) {
		this.empSalary = empSalary;
	}

	public Integer getEmpAge() {
		return empAge;
	}

	public void setEmpAge(Integer empAge) {
		this.empAge = empAge;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", empName=" + empName + ", empEmailId=" + empEmailId + ", empSalary=" + empSalary
				+ ", empAge=" + empAge + ", password=" + password + "]";
	}

}
