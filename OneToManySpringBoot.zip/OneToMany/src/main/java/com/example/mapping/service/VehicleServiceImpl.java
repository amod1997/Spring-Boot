package com.example.mapping.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.mapping.dto.Vehicle;
import com.example.mapping.repository.VehicleRepository;

@Service
public class VehicleServiceImpl implements VehicleService {

	@Autowired
	private VehicleRepository vehicleRepository;

	@Override
	public void saveVehicle(Vehicle vehicle) {
		if (vehicle != null)
			vehicleRepository.save(vehicle);
	}

}
