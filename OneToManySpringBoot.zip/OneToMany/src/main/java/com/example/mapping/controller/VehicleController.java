package com.example.mapping.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.mapping.dto.Vehicle;
import com.example.mapping.service.VehicleServiceImpl;

@RestController
@RequestMapping("/vehicle")
public class VehicleController {

	@Autowired
	private VehicleServiceImpl vehicleService;

	@PostMapping("/add")
	public ResponseEntity<String> saveVehicle(@RequestBody Vehicle vehicle) {
		vehicleService.saveVehicle(vehicle);
		return new ResponseEntity<String>("Vehicle Data added successfully", HttpStatus.OK);
	}

}
