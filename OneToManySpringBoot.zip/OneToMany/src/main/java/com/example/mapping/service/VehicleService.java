package com.example.mapping.service;

import com.example.mapping.dto.Vehicle;

public interface VehicleService {

	public void saveVehicle(Vehicle vehicle);
	
}
