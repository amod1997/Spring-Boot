package com.example.mapping.service;

import com.example.mapping.dto.User;

public interface UserService {

	public void saveUser(User user);
	
}
