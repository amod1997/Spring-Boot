package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.entity.Student;
import com.example.demo.implementation.StudentServiceImpl;

@SpringBootApplication
public class IntegrationPocApplication implements CommandLineRunner {

	@Autowired
	private StudentServiceImpl studentServiceImpl;

	public static void main(String[] args) {
		SpringApplication.run(IntegrationPocApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		Student student = new Student("1", "Alex", "alex@gmail.com");
		Student student1 = new Student("2", "Alexa", "alexa@gmail.com");
		Student student2 = new Student("3", "Alexaa", "alexaa@gmail.com");
		Student student3 = new Student("4", "Alexuu", "alexuu@gmail.com");
		studentServiceImpl.addStudent(student);
		studentServiceImpl.addStudent(student1);
		studentServiceImpl.addStudent(student2);
		studentServiceImpl.addStudent(student3);

	}

}
