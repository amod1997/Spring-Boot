/**
 * 
 */
package com.example.demo.implementation;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Student;
import com.example.demo.repository.StudentRepository;
import com.example.demo.service.StudentService;

/**
 * @author amod.kunwar
 *
 */
@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentRepository studentRepository;

	@Override
	public List<Student> getAllStudent() {
		List<Student> studentList = new ArrayList<>();
		studentRepository.findAll().forEach(student -> studentList.add(student));
		return studentList;
	}

	@Override
	public Student addStudent(Student student) {
		return studentRepository.save(student);
	}

	@Override
	public Optional<Student> findByStudentId(String studentId) {
		Optional<Student> findById = studentRepository.findById(studentId);
		return findById;
	}

	@Override
	public Student updateStudent(Student student) {
		return studentRepository.save(student);
	}

	@Override
	public void deleteByStudentId(String studentId) {
		studentRepository.deleteById(studentId);
	}

	@Override
	public void deleteAllStudent() {
		studentRepository.deleteAll();
	}

}
