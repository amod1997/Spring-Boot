/**
 * 
 */
package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Student;

/**
 * @author amod.kunwar
 *
 */
@Service
public interface StudentService {

	public Student addStudent(Student student);

	public List<Student> getAllStudent();

	public Optional<Student> findByStudentId(String studentId);

	public Student updateStudent(Student student);

	public void deleteByStudentId(String studentId);

	public void deleteAllStudent();

}
