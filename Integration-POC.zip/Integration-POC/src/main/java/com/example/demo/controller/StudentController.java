/**
 * 
 */
package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Student;
import com.example.demo.implementation.StudentServiceImpl;

/**
 * @author amod.kunwar
 *
 */
@RestController
@RequestMapping("/student")
public class StudentController {

	@Autowired
	private StudentServiceImpl studentServiceImpl;

	@PostMapping("/addStudent")
	public Student addStudent(@RequestBody Student student) {
		return studentServiceImpl.addStudent(student);
	}

	@GetMapping("/getAllStudent")
	public List<Student> getAllStudent() {
		return studentServiceImpl.getAllStudent();
	}

	@GetMapping("/{studentId}")
	public Student getDetailsByStudentId(@PathVariable("studentId") String studentId) throws Exception {
		Optional<Student> findByStudentId = studentServiceImpl.findByStudentId(studentId);
		if (!findByStudentId.isPresent()) {
			throw new Exception("Cannot find the student with Id " + studentId);
		}
		return findByStudentId.get();
	}

	@PutMapping("/update/{studentId}")
	public Student updateStudent(@RequestBody Student student, @PathVariable("studentId") String studentId)
			throws Exception {
		Optional<Student> findByStudentId = studentServiceImpl.findByStudentId(studentId);
		if (!findByStudentId.isPresent()) {
			throw new Exception("Cannot find the student with Id " + studentId);
		}
		if (student.getStudentName() == null || student.getStudentName().isEmpty()) {
			student.setStudentName(findByStudentId.get().getStudentName());
		}
		if (student.getStudentEmail() == null || student.getStudentEmail().isEmpty()) {
			student.setStudentEmail(findByStudentId.get().getStudentEmail());
		}
		student.setStudentId(studentId);
		return studentServiceImpl.updateStudent(student);
	}

	@DeleteMapping("/{studentId}")
	public ResponseEntity<String> deleteById(@PathVariable("studentId") String studentId) {
		studentServiceImpl.deleteByStudentId(studentId);
		return new ResponseEntity<String>("deleted by id", HttpStatus.OK);
	}

	@DeleteMapping("/deleteAll")
	public ResponseEntity<String> deleteAllStudentRecord() {
		studentServiceImpl.deleteAllStudent();
		return new ResponseEntity<String>("deleted All Student Record", HttpStatus.OK);
	}

}
