/**
 * 
 */
package com.example.demo.controller;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.demo.IntegrationPocApplication;
import com.example.demo.entity.Student;

/**
 * @author amod.kunwar
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = IntegrationPocApplication.class, webEnvironment = SpringBootTest.WebEnvironment.NONE)
public class UpdateStudentIntegrationTest {

	String url = "http://localhost:9999/student/update/12345";

	@Test
	public void updateStudent_integrationTest() {
		TestRestTemplate restTemplate = new TestRestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		Student student = new Student();
		student.setStudentEmail("kirti.x@gmail.com");
		student.setStudentName("Kirti X");

		HttpEntity<Student> request = new HttpEntity<Student>(student);

		ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.PUT, request, String.class);

		int statusCodeValue = response.getStatusCodeValue();

		if (statusCodeValue == 200) {
			assertEquals(200, statusCodeValue);
		} else {
			assertEquals(500, statusCodeValue);
		}

	}

}
