package com.example.demo.controller;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.demo.IntegrationPocApplication;
import com.example.demo.entity.Student;
import com.google.gson.Gson;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = IntegrationPocApplication.class, webEnvironment = SpringBootTest.WebEnvironment.NONE)
public class GetAllStudentIntegrationTest {

	String url = "http://localhost:9999/student/getAllStudent";

	TestRestTemplate testRestTemplate = new TestRestTemplate();
	HttpHeaders headers = new HttpHeaders();

	@Test
	public void getAllStudents_integrationTest() {
		headers.setContentType(MediaType.APPLICATION_JSON);
		Student student = new Student();
		HttpEntity<Student> request = new HttpEntity<Student>(student);
		ResponseEntity<String> response = testRestTemplate.exchange(url, HttpMethod.GET, request, String.class);
		int statusCodeValue = response.getStatusCodeValue();
		if (statusCodeValue == 200) {
			assertEquals(200, statusCodeValue);
		} else {
			assertEquals(404, statusCodeValue);
		}
	}

}
