package com.example.demo.controller;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.demo.IntegrationPocApplication;
import com.example.demo.entity.Student;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = IntegrationPocApplication.class, webEnvironment = SpringBootTest.WebEnvironment.NONE)
public class UpdateByIdintegrationTest {

	String url = "http://localhost:9999/student/update/1";

	TestRestTemplate template = new TestRestTemplate();
	HttpHeaders headers = new HttpHeaders();

	@Test
	public void updateById_integrationTest() {
		headers.setContentType(MediaType.APPLICATION_JSON);
		Student student = new Student();
		student.setStudentName("Amod");
		student.setStudentEmail("amod@gmail.com");
		HttpEntity<Student> request = new HttpEntity<Student>(student);
		ResponseEntity<String> response = template.exchange(url, HttpMethod.PUT, request, String.class);

		if (200 == response.getStatusCodeValue()) {
			assertEquals(200, response.getStatusCodeValue());
		} else {
			assertEquals(404, response.getStatusCodeValue());
		}

	}

}
