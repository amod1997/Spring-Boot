/**
 * 
 */
package com.example.demo.controller;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.demo.IntegrationPocApplication;
import com.example.demo.entity.Student;

/**
 * @author amod.kunwar
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = IntegrationPocApplication.class, webEnvironment = SpringBootTest.WebEnvironment.NONE)
public class DeleteStudentIntegrationTest {

	String url = "http://localhost:9999/student/12345";

	@Test
	public void deleteStudent_intgerationTest() {
		TestRestTemplate restTemplate = new TestRestTemplate();

		Student student = new Student();

		HttpEntity<Student> request = new HttpEntity<Student>(student);

		ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.DELETE, request, String.class);

		int statusCodeValue = response.getStatusCodeValue();

		if (statusCodeValue == 200) {
			assertEquals(200, statusCodeValue);
		} else {
			assertEquals(500, statusCodeValue);
		}

	}

}
