/**
 * 
 */
package com.example.demo.controller;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.demo.IntegrationPocApplication;
import com.example.demo.entity.Student;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = IntegrationPocApplication.class, webEnvironment = SpringBootTest.WebEnvironment.NONE)
public class AddStudentIntegrationTest {

	String url = "http://localhost:9999/student/addStudent";

	TestRestTemplate testRestTemplate = new TestRestTemplate();
	HttpHeaders headers = new HttpHeaders();

	@Test
	public void addStudent_integrationTest() {

		headers.setContentType(MediaType.APPLICATION_JSON);

		Student student = new Student();

		student.setStudentId("12345");
		student.setStudentName("kirti");
		student.setStudentEmail("kirti@gmail.com");

		HttpEntity<Student> request = new HttpEntity<Student>(student);

		ResponseEntity<String> response = testRestTemplate.exchange(url, HttpMethod.POST, request, String.class);

		int statusCodeValue = response.getStatusCodeValue();
		if (statusCodeValue == 200) {
			assertEquals(200, statusCodeValue);
		} else {
			assertEquals(500, statusCodeValue);
		}

	}

}
