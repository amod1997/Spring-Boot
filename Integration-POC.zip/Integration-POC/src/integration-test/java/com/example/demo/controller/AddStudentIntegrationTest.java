/**
 * 
 */
package com.example.demo.controller;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.demo.IntegrationPocApplication;
import com.example.demo.entity.Student;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = IntegrationPocApplication.class, webEnvironment = SpringBootTest.WebEnvironment.NONE)
public class AddStudentIntegrationTest {

	String url = "http://localhost:9999/student/addStudent";

	TestRestTemplate testRestTemplate = new TestRestTemplate();
	HttpHeaders headers = new HttpHeaders();

	@Test
	public void addStudent_integrationTest() {

		headers.setContentType(MediaType.APPLICATION_JSON);

		Student student = new Student();

		student.setStudentId("12345");
		student.setStudentName("kirti");
		student.setStudentEmail("kirti@gmail.com");

		Student student1 = new Student();

		student1.setStudentId("12346");
		student1.setStudentName("Abhi");
		student1.setStudentEmail("abhi@gmail.com");

		HttpEntity<Student> request = new HttpEntity<Student>(student);
		HttpEntity<Student> request1 = new HttpEntity<Student>(student1);

		ResponseEntity<String> response = testRestTemplate.exchange(url, HttpMethod.POST, request, String.class);
		ResponseEntity<String> response1 = testRestTemplate.exchange(url, HttpMethod.POST, request1, String.class);

		int statusCodeValue = response.getStatusCodeValue();

		if (statusCodeValue == 200) {
			assertEquals(200, statusCodeValue);
		} else {
			assertEquals(404, statusCodeValue);
		}

		int statusCodeValue2 = response1.getStatusCodeValue();

		if (statusCodeValue2 == 200) {
			assertEquals(200, statusCodeValue2);
		} else {
			assertEquals(404, statusCodeValue2);
		}

	}

}
