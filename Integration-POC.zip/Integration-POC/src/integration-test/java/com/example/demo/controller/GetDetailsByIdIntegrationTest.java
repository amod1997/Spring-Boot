/**
 * 
 */
package com.example.demo.controller;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.demo.IntegrationPocApplication;
import com.example.demo.entity.Student;
import com.google.gson.Gson;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = IntegrationPocApplication.class, webEnvironment = SpringBootTest.WebEnvironment.NONE)
public class GetDetailsByIdIntegrationTest {

	String url = "http://localhost:9999/student/1";

	TestRestTemplate template = new TestRestTemplate();
	HttpHeaders headers = new HttpHeaders();

	@Test
	public void testGetStudentById_integrationTest() {
		headers.setContentType(MediaType.APPLICATION_JSON);
		Student student = new Student();
		student.setStudentId("1");
		student.setStudentName("Alex");
		student.setStudentEmail("alex@gmail.com");
		HttpEntity<Student> request = new HttpEntity<Student>(student);
		ResponseEntity<String> response = template.exchange(url, HttpMethod.GET, request, String.class);
		Gson gson = new Gson();
		// converting java object to Json Object.
		String json = gson.toJson(request.getBody());
		System.out.println("Request Body " + json);
		System.out.println("Response Body " + response.getBody());
		// comparing request body and response body.
		assertEquals(json, response.getBody());
	}

}
