/**
 * 
 */
package com.example.demo.config;

import java.util.Properties;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(entityManagerFactoryRef = "bookingEntityManager", transactionManagerRef = "bookingTransactionManager", basePackages = "com.example.demo.booking.repository")
public class BookingDBConfig {

	@Autowired
	private Environment envVariable;

	@Bean
	@ConfigurationProperties(value = "spring.booking.datasource")
	public DataSourceProperties bookingDataSourceProperties() {
		return new DataSourceProperties();
	}

	@Bean
	public DataSource bookingDataSource() {
		DataSourceProperties bookingDataSourceProperties = bookingDataSourceProperties();
		return DataSourceBuilder.create().driverClassName(bookingDataSourceProperties.getDriverClassName())
				.url(bookingDataSourceProperties.getUrl()).username(bookingDataSourceProperties.getUsername())
				.password(bookingDataSourceProperties.getPassword()).build();
	}

	@Bean
	public PlatformTransactionManager bookingTransactionManager() {
		EntityManagerFactory bookingEdgeFactory = bookingEntityManager().getObject();
		return new JpaTransactionManager(bookingEdgeFactory);
	}

	@Bean
	public LocalContainerEntityManagerFactoryBean bookingEntityManager() {
		LocalContainerEntityManagerFactoryBean factory = new LocalContainerEntityManagerFactoryBean();
		factory.setDataSource(bookingDataSource());
		factory.setPackagesToScan("com.example.demo.booking.entity");
		factory.setJpaVendorAdapter(new HibernateJpaVendorAdapter());
		Properties jpaProperties = new Properties();
		jpaProperties.put("spring.jpa.show-sql", envVariable.getProperty("spring.jpa.show-sql"));
		jpaProperties.put("spring.jpa.database-platform", envVariable.getProperty("spring.jpa.database-platform"));
		jpaProperties.put("spring.booking.datasource.url", envVariable.getProperty("spring.booking.datasource.url"));
		jpaProperties.put("spring.booking.datasource.driverClassName",
				envVariable.getProperty("spring.booking.datasource.driverClassName"));
		jpaProperties.put("spring.booking.datasource.username",
				envVariable.getProperty("spring.booking.datasource.username"));
		jpaProperties.put("spring.booking.h2.console.path", envVariable.getProperty("spring.booking.h2.console.path"));
		factory.setJpaProperties(jpaProperties);
		return factory;
	}

}