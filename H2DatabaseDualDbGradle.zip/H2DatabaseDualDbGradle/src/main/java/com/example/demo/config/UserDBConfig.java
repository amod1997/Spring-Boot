package com.example.demo.config;

import java.util.Properties;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * @author amod.kunwar
 *
 */
@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(entityManagerFactoryRef = "userEntityManager", transactionManagerRef = "userTransactionManager", basePackages = "com.example.demo.user.repository")
public class UserDBConfig {

	@Autowired
	private Environment envVariable;

	@Primary
	@Bean
	@ConfigurationProperties(value = "spring.datasource")
	public DataSourceProperties fxgLocEdgeDataSourceProperties() {
		return new DataSourceProperties();
	}

	@Primary
	@Bean
	public DataSource userDataSource() {
		DataSourceProperties bookingDataSourceProperties = fxgLocEdgeDataSourceProperties();
		return DataSourceBuilder.create().driverClassName(bookingDataSourceProperties.getDriverClassName())
				.url(bookingDataSourceProperties.getUrl()).username(bookingDataSourceProperties.getUsername())
				.password(bookingDataSourceProperties.getPassword()).build();
	}

	@Primary
	@Bean
	public PlatformTransactionManager userTransactionManager() {
		EntityManagerFactory bookingEdgeFactory = userEntityManager().getObject();
		return new JpaTransactionManager(bookingEdgeFactory);
	}

	@Primary
	@Bean
	public LocalContainerEntityManagerFactoryBean userEntityManager() {
		LocalContainerEntityManagerFactoryBean factory = new LocalContainerEntityManagerFactoryBean();
		factory.setDataSource(userDataSource());
		factory.setPackagesToScan("com.example.demo.user.entity");
		factory.setJpaVendorAdapter(new HibernateJpaVendorAdapter());
		Properties jpaProperties = new Properties();
		jpaProperties.put("spring.jpa.show-sql", envVariable.getProperty("spring.jpa.show-sql"));
		jpaProperties.put("spring.jpa.database-platform", envVariable.getProperty("spring.jpa.database-platform"));
		jpaProperties.put("spring.datasource.url", envVariable.getProperty("spring.datasource.url"));
		jpaProperties.put("spring.datasource.driverClassName",
				envVariable.getProperty("spring.datasource.driverClassName"));
		jpaProperties.put("spring.user.datasource.username", envVariable.getProperty("spring.datasource.username"));
		jpaProperties.put("spring.h2.console.path", envVariable.getProperty("spring.h2.console.path"));
		factory.setJpaProperties(jpaProperties);
		return factory;
	}

}