/**
 * 
 */
package com.example.demo.booking.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.booking.entity.Booking;

/**
 * @author amod.kunwar
 *
 */
public interface BookingDAO extends CrudRepository<Booking, Long> {

	List findByCreatedBy(Long userId);

}
