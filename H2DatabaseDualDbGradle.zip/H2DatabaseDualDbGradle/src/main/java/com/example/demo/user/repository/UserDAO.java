/**
 * 
 */
package com.example.demo.user.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.user.entity.UserDetails;

/**
 * @author amod.kunwar
 *
 */
public interface UserDAO extends CrudRepository<UserDetails, Long> {

	UserDetails findByEmail(String email);

}
